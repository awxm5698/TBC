#!/usr/bin/env python2
# -*- coding: utf-8 -*-

# import sys, os
# reload(sys)
# sys.setdefaultencoding('utf-8')
# sys.dont_write_bytecode = True
# path = os.path.split(os.path.realpath(__file__))[0]
# sys.path.append(path[0:path.rfind("\\")])

import unittest
from test_data import config
from test_data import set_post_data
from common import elastic_search
from common import common_requests
from common import check_result
import random


#################################################################
# --------------------------用例参数--------------------------- #
#################################################################
'''
instanttiate common_requests
:return:
'''
api_url = config.api_url
t = common_requests.testCommon(api_url)
get_data = set_post_data.set_data()
'''
instanttiate ElasticObj
:return:
'''
es_ip = config.es_ip
index_type = config.index_type
index_name = config.index_name
es = elastic_search.ElasticObj(index_name,index_type,es_ip)


#################################################################
# ---------------------------启动模块-------------------------- #
#################################################################
class MyTest(unittest.TestCase):
    def setUp(self):
        print ("strat test")
        pass

    def tearDown(self):
        print ("end test")
        pass


#################################################################
# ---------------------------用例脚本-------------------------- #
#################################################################



class test_API_searchByTireSize(MyTest):

    def test_check_api_and_es_results(self):
        data = get_data.get_tires_data()
        form_data = data.get("form_data")
        path = config.path['get_searchByTireSize']
        response = t.post(path, form_data)
        self.assertEqual(response.json().get('code'),100000)
        self.assertEqual(response.json().get('message'),'success')

        '''get es results'''
        doc = data.get("docs")
        res = es.Get_Data_By_Body(doc)
        self.assertEqual(res.get('timed_out'), False)

        '''实例化 check'''
        items = response.json().get('data').get('items')
        hits = res.get("hits").get("hits")
        check = check_result.check_results(items,hits)
        aggs = response.json().get('data').get('aggs')
        print(aggs)

        '''将api与es的结果对比'''
        # check productId
        check.check_result('productId')
        # check upc
        check.check_result("upc")
        # check tireSideWall
        check.check_result("tireSideWall")
        for agg in aggs:
            if agg.get("name") == "tireSideWall":
                tireSideWall = agg.get("value")
        print("tireSideWall=" + str(tireSideWall))
        # check productName
        check.check_result("productName")
        # check tireSizeAttributes
        check.check_result("tireSizeAttributes")
        # check tireSpeedRating
        check.check_result("tireSpeedRating")
        # check tireLoadIndex
        check.check_result("tireLoadIndex")
        for agg in aggs:
            if agg.get("name") == "tireLoadIndex":
                tireLoadIndex = agg.get("value")
        print("tireLoadIndex="+str(tireLoadIndex))
        # check season
        check.check_result("season")

        # check brand
        check.check_result("brand")
        for agg in aggs:
            if agg.get("name") == "brand":
                brand = agg.get("value")
        print("brand="+str(brand))
        # check warrantyInfo
        check.check_result("warrantyInfo")
        for agg in aggs:
            if agg.get("name") == "warrantyInfo":
                warrantyInfo = agg.get("value")
        print("warrantyInfo=" + str(warrantyInfo))

    def test_check_search_tilter(self):
        data = get_data.get_tires_data()
        form_data = data.get("form_data")
        path = config.path['get_searchByTireSize']
        response = t.post(path, form_data)
        self.assertEqual(response.json().get('code'),100000)
        self.assertEqual(response.json().get('message'),'success')
        items = response.json().get('data').get('items')

        '''get brand from api result'''
        brands = []
        for item in items:
            if item not in brands:   # 去除重复brand
                brands.append(item.get('brand'))
        brand = random.sample(brands, 1)  #从结果随机取一个brand

        '''增加过滤条件brand通过api去查询'''
        form_data["brand"] = brand
        brand_response = t.post(path, form_data)
        self.assertEqual(brand_response.json().get('code'), 100000)
        self.assertEqual(brand_response.json().get('message'), 'success')
        brand_items = brand_response.json().get('data').get('items')

        '''再从过滤结果里面取brand'''
        for item in brand_items:
            self.assertEqual(item.get('brand'),brand[0])

        '''增加过滤条件brand通过es去查询'''
        brand = get_data.tire_data("brand", brand[0])
        doc = data.get("docs")
        doc["query"]["bool"]["must"].append(brand)

        es_response = es.Get_Data_By_Body(doc)

        self.assertEqual(es_response.get('timed_out'), False)

        '''实例化 check'''
        items = brand_response.json().get('data').get('items')
        hits = es_response.get("hits").get("hits")
        check = check_result.check_results(items,hits)

        '''将api与es的结果对比'''
        # check productId
        check.check_result('productId')
        # check upc
        check.check_result("upc")
        # check tireSideWall
        check.check_result("tireSideWall")
        # check productName
        check.check_result("productName")
        # check brand
        check.check_result("brand")
        # check tireLoadIndex
        check.check_result("tireLoadIndex")
        # check season
        check.check_result("season")
        # check tireSizeAttributes
        # check.check_result("tireSizeAttributes")
        # check tireSpeedRating
        # check.check_result("tireSpeedRating")





#################################################################
# ---------------------------执行用例-------------------------- #
#################################################################
if __name__ == "__main__":
    unittest.main()


