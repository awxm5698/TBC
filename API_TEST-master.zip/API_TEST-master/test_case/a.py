#!/usr/bin/env python2
# -*- coding:utf-8 -*-


import sys, os
# reload(sys)
# sys.setdefaultencoding('utf-8')
# sys.dont_write_bytecode = True
# path = os.path.split(os.path.realpath(__file__))[0]
# sys.path.append(path[0:path.rfind("\\")])

import unittest
from test_data import config
from test_data import set_post_data
from common import elastic_search
from common import common_requests
from common import check_result

#################################################################
# --------------------------用例参数--------------------------- #
#################################################################
'''
instanttiate common_requests
:return:
'''
api_url = config.api_url
t = common_requests.testCommon(api_url)
get_data = set_post_data.set_data()
'''
instanttiate ElasticObj
:return:
'''
es_ip = config.es_ip
index_type = config.index_type
index_name = config.index_name
es = elastic_search.ElasticObj(index_name,index_type,es_ip)


#################################################################
# ---------------------------启动模块-------------------------- #
#################################################################
class MyTest(unittest.TestCase):
    def setUp(self):
        print ("strat test")
        pass

    def tearDown(self):
        print ("end test")
        pass


#################################################################
# ---------------------------用例脚本-------------------------- #
#################################################################
class test_API_searchByVehicleType(MyTest):

    def test_check_api_and_es_results(self):
        data = get_data.get_vehicletpye_data()
        form_data = data.get("form_data")
        path = config.path['get_searchByVehicleType']
        response = t.post(path, form_data)
        self.assertEqual(response.json().get('code'),100000)
        self.assertEqual(response.json().get('message'),'success')

        '''
        get es results
        '''
        doc = data.get("docs")
        doc['size'] = 10000
        es_response = es.Get_Data_By_Body(doc)
        self.assertEqual(es_response.get('timed_out'), False)

        '''
        instanttiate check
        '''
        items = response.json().get('data').get('items')
        hits = es_response.get("hits").get("hits")
        check = check_result.check_results(items, hits)
        aggs = response.json()['data']['aggs']
        es_buckets = es_response['aggregations']['brand']['buckets']
        brands = check.get_aggs_value_by_name(aggs,'brand')
        print(brands)
        es_brands = check.get_es_buckets_value_by_key(es_buckets,'brand')
        print(es_brands)
        count_brands = check.get_es_value_list(hits,'brand')
        count_brands.sort()

        print(count_brands)
        self.assertListEqual(brands, es_brands)
        self.assertListEqual(brands, count_brands)

#################################################################
# ---------------------------执行用例-------------------------- #
#################################################################
if __name__ == "__main__":
    unittest.main()




