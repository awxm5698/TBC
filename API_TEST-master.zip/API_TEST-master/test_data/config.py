#!/usr/bin/env python2
# -*- coding: utf-8 -*-

api_url = "https://dev-tirebattery-webapp.azurewebsites.net"

path = {"get_searchByTireSize": "/item/tire/searchByTireSize",
        "get_searchByVehicleType": "/item/tire/searchByVehicleType"
        }

json_path = {}


db_url = 'https://dev-tirebattery-app.documents.azure.com:443/ '
key = 'lXy59oFu6uAbraxLgbMIyh8EF242LIqBvEBuuZWD82Su98xulfi82HuSZt74iFTf6zRx9e2AvwEZdzKPhmgq6g=='
db_name = 'TBC_QA'

post_tire_size_pram = {
    "avgRating": [],
    "brand": [],
    "brandOrderBy": "",
    "clubId": [],
    "keywords": [],
    "page": 0,
    "pageSize": 20,
    "priceOrderBy": "",
    "recommended": [],
    "rimDiameter": [],
    "rimSize": ["14"],
    "season": [],
    "terrain": [],
    "tireLoadIndex": [],
    "tireRatio": ["75"],
    "tireSideWall": [],
    "tireSizes": [],
    "tireSpeedRating": [],
    "warrantyInfo": [],
    "width": ["195"]
    }


es_ip = '168.61.148.253'
index_type = '_doc'
index_name = 'item_tire_detail'




