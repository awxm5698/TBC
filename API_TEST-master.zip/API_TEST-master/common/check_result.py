#!/usr/bin/env python2
# -*- coding:utf-8 -*-
import unittest

class check_results(unittest.TestCase):

    def __init__(self,items=None,hits=None):

        self.items = items
        self.hits = hits

    def check_result(self, pram):
        # items = response.json().get('data').get('items')
        api_value_list = self.get_api_value_list(self.items, pram)

        # hits = res.get("hits").get("hits")
        es_value_list = self.get_es_value_list(self.hits, pram)
        try:
            self.assertListEqual(api_value_list, es_value_list)

            print("pass :api_"+pram+"("+str(len(api_value_list)) + ") = "+str(api_value_list))
            print("pass : es_"+pram+"("+str(len(es_value_list)) + ") = "+str(es_value_list))
        except:
            print("fail :api_"+pram+"("+str(len(api_value_list)) + ") = "+str(api_value_list))
            print("fail : es_"+pram+"("+str(len(es_value_list)) + ") = "+str(es_value_list))
            # assert False
            result = False


    def get_api_value_list(self, items, pram):
        arr = []
        for item in items:
            if str(item.get(pram)) not in arr:
                arr.append(str(item.get(pram)))

        # arr.sort()
        return arr

    def get_es_value_list(self, hits, pram):
        arr = []
        for hit in hits:
            if str(hit.get("_source").get(pram)) not in arr:
                arr.append(str(hit.get("_source").get(pram)))

        # arr.sort()
        return arr

    def get_aggs_value_by_name(self,aggs,name):
        for agg in aggs:
            if agg['name'] == name:
                values = agg['value']
        values.sort()
        return values

    def get_es_buckets_value_by_key(self, es_buckets, key):
        es_values = []
        for key in es_buckets:
            es_values.append(key['key'])
        es_values.sort()
        return es_values

class check_assert_result(unittest.TestCase):

    def __init__(self):
        pass

    def check_list(self,list1, list2):

        try:
            self.assertListEqual(list1, list2)
            print("pass :" + str(list1) )
            print("pass :" + str(list2) )
        except:
            print("fail :" + str(list1) )
            print("fail :" + str(list2) )
            # assert False
            result = False
