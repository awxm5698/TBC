#!/usr/bin/env python2
# -*- coding:utf-8 -*-
# os.path.split(os.path.realpath(__file__))[0]  # 打印当前文件的绝对路径,./a/a.py调用./b/b.py,打印./b
# os.path.split(os.path.abspath(sys.argv[0]))[0] # 打印执行文件的绝对路径，./a/a.py调用./b/b.py,打印./a
			
import requests,logging
from requests import exceptions
from requests_toolbelt import SSLAdapter
import sys,os,re
#path = os.path.split(os.path.abspath(sys.argv[0]))[0]

sys.dont_write_bytecode = True
logging.basicConfig(level=logging.NOTSET)

class testCommon():
	def __init__(self,url,port=None):
		if port == "" or port == None:
			self.url = url
		else:
			self.url = url + ":"+port
		
	def get(self,path,form_data=None):
		try:
			headers={'Connection':'close'}
			requests.packages.urllib3.disable_warnings()
			response = requests.get(self.url + path, params = form_data,headers = headers, verify=False)
			#response.encoding = 'utf-8'
			#print response.url
			#print response.cookies
			#print response.json()
			logging.info("form_data=" + str(form_data))
			logging.info("response=" + str(response.json()))
			return response #获取服务器返回的页面信息
		except exceptions.HTTPError as e:
			return 'Error: ',e
			
	def post(self,path,form_data):
		try:
			headers = {'accept':'*/*','Content-Type':'application/json'}
			response = requests.post(self.url + path, json = form_data,headers = headers)
			#print response.status_code
			#print response.headers
			#print response.cookies
			logging.info("form_data=" + str(form_data))
			logging.info("response=" + str(response.json()))
			return response
		except exceptions.HTTPError as e:
			return 'Error: ',e





if __name__ == "__main__":
	url = "http://168.61.148.253"
	port = "8080"
	year = '2017'
	path = '/item/vehicle/makes/'+year
	wordbook = ''
	t = testCommon(url,port)
	response = t.post(path,wordbook)
	print (response.json())
	

	
	
